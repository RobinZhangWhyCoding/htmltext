# -*- coding: utf-8 -*-

name = "htmltext"

from .htmltext import HTMLText

__all__ = ["HTMLText"]
